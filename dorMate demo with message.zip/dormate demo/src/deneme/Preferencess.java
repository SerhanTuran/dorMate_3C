/*package deneme;



public class Preferencess {
    private int[] preferencess = new int[5];

    public Preferencess(){
        preferencess = new int[5];
        for(int i = 0; i < 5; i++){
            preferencess[i]  = 0;
        }
    }
    //index 0 = bed time
    public void setBedTime(int bedTime){
        preferencess[0] = bedTime;
    }
    //index 1 = phonecall
    public void setPhonecall(int phonecall){
        preferencess[1] = phonecall;
    }
    //index 2 = eating habits
    public void setEatingFrequency(int eatingFrequency){
        preferencess[2] = eatingFrequency;
    }
    //index 3 = game habits
    public void setGamingFrequency(int gamingFrequency){
        preferencess[3] = gamingFrequency;
    }
    //index 4 = study habits
    public void setStudyFrequency(int studyFrequency){
        preferencess[4] = studyFrequency;
    }
    //Getter
    public int[] getPrefereces(){
        return preferencess;
    }

}*/